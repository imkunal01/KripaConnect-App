
  # Kripa Connect E-commerce UI/UX

  This is a code bundle for Kripa Connect E-commerce UI/UX. The original project is available at https://www.figma.com/design/shpVZSGI1rcQ6eCAaeQQYC/Kripa-Connect-E-commerce-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  